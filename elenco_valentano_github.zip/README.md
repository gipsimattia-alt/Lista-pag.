# Elenco Valentino

Web app semplice per gestire l'elenco dei pagamenti.

## Funzioni
- Lista degli 11 nominativi
- Checkbox cliccabile per segnare un pagamento
- Salvataggio automatico nel browser tramite `localStorage`
- Ricerca per nome
- Contatore dei pagamenti
- Totale incassato
- Layout responsive per smartphone e PC
- Nessun database o server necessario

## Pubblicazione su GitHub Pages

1. Crea un nuovo repository pubblico su GitHub.
2. Carica `index.html`, `style.css` e `script.js`.
3. Vai in **Settings → Pages**.
4. In **Build and deployment**, seleziona **Deploy from a branch**.
5. Seleziona il branch `main` e la cartella `/root`.
6. Salva: GitHub genererà il link pubblico del sito.

### Modificare i nomi

Apri `script.js` e modifica l'array `people`.

### Modificare il prezzo

In `script.js` modifica:

```js
const PRICE = 35;
```

Il prezzo viene mostrato automaticamente in tutti gli elementi e il totale viene ricalcolato.

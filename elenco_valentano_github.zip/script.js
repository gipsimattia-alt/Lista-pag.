const people = [
  "Bendetta Bartoccini",
  "Rachele Mazzei",
  "Gabriele Biagini",
  "Alberto Magrini",
  "Davide Bussotti",
  "Michel Santini",
  "Alex Gentili",
  "Leonardo Funghi",
  "Giuseppe Flacca",
  "Filippo Morandi",
  "Agnese Zapponi"
];

const PRICE = 35;
const STORAGE_KEY = "elenco-valentino-paid-v1";

const list = document.getElementById("list");
const searchInput = document.getElementById("searchInput");
const paidCount = document.getElementById("paidCount");
const totalCount = document.getElementById("totalCount");
const paidTotal = document.getElementById("paidTotal");
const resetButton = document.getElementById("resetButton");

let paid = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");

function euro(value) {
  return new Intl.NumberFormat("it-IT", {
    style: "currency",
    currency: "EUR"
  }).format(value);
}

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(paid));
}

function render() {
  const query = searchInput.value.trim().toLowerCase();
  const filtered = people
    .map((name, index) => ({ name, index }))
    .filter(person => person.name.toLowerCase().includes(query));

  list.innerHTML = "";

  if (!filtered.length) {
    list.innerHTML = '<div class="empty">Nessun nome trovato.</div>';
  } else {
    filtered.forEach(({name, index}) => {
      const isPaid = Boolean(paid[index]);
      const row = document.createElement("div");
      row.className = `person${isPaid ? " paid" : ""}`;
      row.setAttribute("role", "button");
      row.setAttribute("tabindex", "0");
      row.setAttribute("aria-pressed", String(isPaid));

      row.innerHTML = `
        <div class="checkbox" aria-hidden="true">
          <svg viewBox="0 0 24 24"><path d="m5 12 4 4L19 6"/></svg>
        </div>
        <div class="info">
          <p class="name">${escapeHtml(name)}</p>
          <div class="details">Inserito da: Mattia Gipsi</div>
        </div>
        <div class="price">${euro(PRICE)}</div>
      `;

      const toggle = () => {
        paid[index] = !paid[index];
        if (!paid[index]) delete paid[index];
        save();
        render();
      };

      row.addEventListener("click", toggle);
      row.addEventListener("keydown", event => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          toggle();
        }
      });

      list.appendChild(row);
    });
  }

  const count = Object.values(paid).filter(Boolean).length;
  paidCount.textContent = count;
  totalCount.textContent = people.length;
  paidTotal.textContent = euro(count * PRICE);
}

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[char]));
}

searchInput.addEventListener("input", render);

resetButton.addEventListener("click", () => {
  if (confirm("Vuoi davvero azzerare tutti i pagamenti?")) {
    paid = {};
    save();
    render();
  }
});

render();
